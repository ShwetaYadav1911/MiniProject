package com.wipro.video.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.wipro.video.bean.PublisherBean;
import com.wipro.video.bean.VideoBean;
import com.wipro.video.dao.PublisherDAO;
import com.wipro.video.service.Administrator;

/**
 * Servlet implementation class MainServlet
 */
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MainServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    public  String addVideo(HttpServletRequest request) throws ClassNotFoundException, SQLException
    {
    	   Enumeration<String> paramNames = request.getParameterNames();
           VideoBean	bookBean=new VideoBean();
           bookBean.setVideoID(request.getParameter(paramNames.nextElement()));
           
           bookBean.setVideoName(request.getParameter(paramNames.nextElement()));
           String booktype=request.getParameter(paramNames.nextElement() );
           if(request.getParameter(booktype).length()!=0)
               bookBean.setVideoType((booktype).charAt(0));
             else
             {
          	   bookBean.setVideoType('\0');
             }
           PublisherDAO author=new PublisherDAO();
           PublisherBean authorbean=author.getPublisher(request.getParameter(paramNames.nextElement()));
           if(authorbean!=null)
        	   bookBean.setPublisher(authorbean);
           else
        	   return "FAILURE";
           String cost=request.getParameter(paramNames.nextElement());
           if(request.getParameter(cost).length()!=0)
              bookBean.setCost(Double.parseDouble(cost));
           else
        	   bookBean.setCost(0.0); 
           bookBean.setDateOfPublish(new Date(paramNames.nextElement()));
           Administrator admin=new Administrator();
           
          String s=admin.addVideo(bookBean);
          return s;
    }
    public int deleteVideo(String isbn)
    {
    	if(isbn.length()==0)
    		return 0;
    	Administrator admin=new Administrator();
    	
    	return admin.deleteVideo(isbn);
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 String operation =request.getParameter("operation");
		
		 if(request.getParameter("operation").equalsIgnoreCase("Add Video"))
		 {
			  try {
				
				String status=addVideo(request);
				//System.out.println(status);
				if (status.equals("SUCCESS"))
					response.sendRedirect("Menu.html");
				else if(status.equals("FAILURE"))
				{
					response.sendRedirect("Failure.html");
				}
				else
					if(status.equals("INVALID"))
					{
						response.sendRedirect("Invalid.html");
					}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 else if(request.getParameter("operation").equalsIgnoreCase("Delete"))
		 {
			    Enumeration<String> paramNames = request.getParameterNames();
			   int book=deleteVideo(request.getParameter(paramNames.nextElement()));
			    if(book==0)
			    {
			    	//response.getWriter().println("There are no books with the given publisher name.");
			    	
						response.sendRedirect("Failure.html");
					
			    }
			    else
			    {
                   
			          response.getWriter().println(book);
			    }
		 }
				 
	}

}
