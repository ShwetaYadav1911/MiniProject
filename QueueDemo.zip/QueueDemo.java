package myProject;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
class QueueIsEmpty extends Exception
{
	public String toString()
	{
		return "Queue is Empty";
	}
}
class Queue
{
	  private List<Integer> queue=new LinkedList<Integer>();;
	  void insert(int x)
	  {
		  
	       queue.add(x);
	       
	  }
	  int delete() throws QueueIsEmpty
	  {   
		  if(queue==null)
			  throw new QueueIsEmpty();
		  return   queue.remove(0);
	  }
}
public class QueueDemo {
       public static void main(String args[]) throws QueueIsEmpty
       {
    	    Queue queue=new Queue();
    	    queue.insert(10);
    	    queue.insert(9);
    	    queue.insert(16);
    	    queue.insert(4);
    	    System.out.println(queue.delete());
    	    System.out.println(queue.delete());
    	    System.out.println(queue.delete());
    	    System.out.println(queue.delete());
    	    
       }
}
