package myProject;
class StackEmptyException extends Exception
{
	 public String toString()
	 {
		 return "Stack is Empty";
	 } 
}
class Node
{
	int d;
	Node next;
    Node()
    {
    	d=0;
    	next=null;
    }
}
class Stack 
{
	protected Node top=null;
	void push(int d)
	{
		  Node t=new Node();
		  t.d=d;
		  t.next=null;
		  if(top==null)
		  {
			    top=t;
		  }
		  else
		  {
			   t.next=top;
			   top=t;
		  }
		  
	}
	int pop()throws StackEmptyException
	{
		 if(top==null)
			throw new StackEmptyException();
		 else
		 {
			 int t=top.d;
			 top=top.next;
			 return t;
		 }
	}
	int isEmpty()
	{
		 if(top==null)
			 return 1;
		 else
			 return 0;
	}
	
}
class MinStackNode extends Node
{
	 MinStackNode nextmin;
	 MinStackNode()
	 {
		  d=0;
		  next=null;
		  nextmin=null;
	 }
}
class MinimumStack extends Stack
{
//	   protected  MinStackNode top;
	   protected  MinStackNode min;
	   void push(int data)
	   {
		   MinStackNode t=new MinStackNode();
		   t.d=data;
		   t.next=null;
		   t.nextmin=null;
		   if(top==null)
		   {
			   top=t;min=t;
		   }
		   else
		   {
			     if(min.d>data)
			     {
			    	 t.nextmin=min;
			    	 min=t;
			     }
			     t.next=top;
				 top=t;
			     
		   }
	   }
	   int  pop() throws StackEmptyException
	   {
		   if(isEmpty()==1)
			   throw new StackEmptyException();
		   else
		   {
			    int t=top.d;
			    top=top.next;
			    return t;
		   }
	   }
	   int getMinimun() throws StackEmptyException
	   {
		      return min.d;
	   }
	   
}
public class StackDemo  {
     
	  public static void main(String args[]) throws StackEmptyException
	  {
		  MinimumStack ob=new MinimumStack();
		      ob.push(7);
		      ob.push(6);
		      ob.push(4);
		      ob.push(1);
		      ob.push(3);
		      System.out.println(ob.getMinimun());
	  } 
}
