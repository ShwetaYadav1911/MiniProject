package com.wipro.video.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.bean.VideoBean;
import com.wipro.video.util.DBUtil;

public class VideoDAO {
	public int deleteVideo(String publisherName) throws SQLException, ClassNotFoundException
	{ 
		 DBUtil dbutil=new DBUtil();
		 Connection con=dbutil.getDBConnection();
		 Statement stmt1,stmt2;
	     stmt1=con.createStatement(); 
	     stmt2=con.createStatement();
	     ResultSet rs1=stmt1.executeQuery("select * from publisher_tbl  where publisher_name='"+publisherName+"'");
	     VideoBean book=new VideoBean();
	     if(rs1.next())
	     {
			   
			     int rs=stmt2.executeUpdate("delete from video_tbl  where publisher_code="+rs1.getInt(1));
			    
                 return rs;
	     }
	     else
	     {
	    	 return 0;
	     }
	}
	public int createVideo(VideoBean videoBean) throws ClassNotFoundException, SQLException
	{
		try
		{
			DBUtil dbutil=new DBUtil();
			 Connection con=dbutil.getDBConnection();
			 Statement stmt1,stmt2;
		     stmt1=con.createStatement(); 
		     ResultSet rs1=stmt1.executeQuery("select * from publisher_tbl  where publisher_name='"+videoBean.getPublisher().getPublisherName()+"'");
			if(rs1.next())
			{
		     PreparedStatement stmt=con.prepareStatement("insert into video_Tbl values(?,?,?,?,?,?)");
			 stmt.setString(1,videoBean.getVideoID());
			 stmt.setString(3,videoBean.getVideoType()+"");
			 stmt.setString(2,videoBean.getVideoName());
			 stmt.setDouble(5,videoBean.getCost());
			 PublisherBean author=videoBean.getPublisher();
			    stmt.setInt(4,author.getPublisherCode());
			    Date d=new Date(videoBean.getDateOfPublish()+"");
			    java.sql.Date date=new java.sql.Date(d.getTime());
			    stmt.setDate(6,date);
			    return stmt.executeUpdate();
			}
			else
				return 0;
			
		}
		catch(Exception e)
		{
			return 0;
		}
	}

}
