package com.wipro.video.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.video.bean.PublisherBean;
import com.wipro.video.util.DBUtil;
public class PublisherDAO {
	public PublisherBean getPublisher(int publisherCode) throws SQLException, ClassNotFoundException
	{
		 DBUtil dbutil=new DBUtil();
		 Connection con=dbutil.getDBConnection();
		 Statement stmt;
	     stmt=con.createStatement(); 
	     ResultSet rs=stmt.executeQuery("select * from publisher_tbl  where publisher_code="+publisherCode);
	     PublisherBean author=new PublisherBean();
	     if(rs!=null)
	     {
			     rs.next();
			     author.setPublisherCode(publisherCode);
			     author.setAddress(rs.getString(3));
			     author.setPublisherName(rs.getString(2));
			     return author;
	     }
	     else
	     {
	    	 return null;
	     }
	}
	public PublisherBean getPublisher (String publisherName)
 	
 throws SQLException, ClassNotFoundException
	{
		
		 DBUtil dbutil=new DBUtil();
		 Connection con=dbutil.getDBConnection();
		 Statement stmt;
	     stmt=con.createStatement(); 
	     ResultSet rs=stmt.executeQuery("select * from publisher_tbl where Author_name='"+publisherName+"'");
	     PublisherBean author=new PublisherBean();
	     if(rs.next())
	     {	 
			     author.setPublisherName(publisherName);
			     author.setPublisherCode(rs.getInt(1));
			     author.setAddress(rs.getString(3));
			     return author;
	     }
	     else
	     {
	    	 return null;
	     }
	}
}
