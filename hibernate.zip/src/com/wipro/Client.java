package com.wipro;
import java.util.*;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args) {
		SessionFactory ss=new Configuration().configure("hiber.cfg.xml").buildSessionFactory();
		Session session =ss.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			Student s1 = new Student();
			s1.setId(1);
			s1.setName("amit");
			
			session.save(s1);
			tx.commit();//will close session
			
		}
		catch(Exception ex){
			System.out.println(ex);
		}
		finally {
			session.close();
		}
	}
}
