package com.wipro.video.service;

import java.sql.SQLException;

import com.wipro.video.bean.VideoBean;
import com.wipro.video.dao.VideoDAO;

public class Administrator {

	public String addVideo(VideoBean videoBean)
	{
	    //if(videoBean!=null&&videoBean.getPublisher().getPublisherName().equals(""))
		  // return "FAILURE";
		if(videoBean==null||videoBean.getVideoName().length()==0||(videoBean.getVideoType()+"").equals("")||!((videoBean.getVideoType()+"").equals("G")||(videoBean.getVideoType()+"").equals("T"))||videoBean.getCost()==0||videoBean.getVideoID().length()==0||videoBean.getPublisher().getPublisherName().equals(""))
		   return "INVALID";
		else
		{
				try {
					VideoDAO bookdao =new VideoDAO();
					if(bookdao.createVideo(videoBean)==1)
					   return "SUCCESS";
					else
						return "FAILURE";
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					return "FAILURE";
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					return "FAILURE";
				}
				
		}
		
	}
	public int deleteVideo(String publisherName)
	{
		

		try {
			
			if(publisherName!=null&&publisherName.length()!=0)
			{
			   VideoDAO bookdao=new VideoDAO();
		       return bookdao.deleteVideo(publisherName);
			  
			}
			else
			{
				
				return 0;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return 0;
		}
		
		
	}

}
