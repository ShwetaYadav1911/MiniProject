package myProject;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;
class Anagram
{
	int checkAnagram(String s1,String s2)
	{
		 HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
	   	   for(int i=0;i<s1.length();i++)
	   	   {
	   		       if(!hm.containsKey(s1.charAt(i)))
	   		       {
	   		    	   hm.put(s1.charAt(i),1);
	   		       }
	   		       else
	   		       {
	   		    	   int m=hm.get(s1.charAt(i));
	   		    	   hm.put(s1.charAt(i),m+1);
	   		       }
	   	   }
	   	   for(int i=0;i<s2.length();i++)
	   	   {
	   		        if(!hm.containsKey(s2.charAt(i)))
	   		        {
	   		    	       return 0;      
	   		    	}
	   		        else
	   		        {
	   		        	int m=hm.get(s2.charAt(i));
	   		        	if(m<0)
	   		        	{
	   		        		return 0;
	   		        	}
	    		    	hm.put(s2.charAt(i),m-1);
	   		        }
	   	   }
	   	    Set<Character> set=hm.keySet();
	   	    for(Character ch:set)
	   	    {
	   		   if(hm.get(ch)!=0)
	   		   {
	   			   return 0;
	   		   }
	   	    }
	   		 return 1;
		
	}
}
public class AnagramDemo {
    public static void main(String args[])
    {
   	   String s1="abbc";
   	   String s2="abbc";
   	    Anagram anagram=new Anagram();
   	    if(anagram.checkAnagram(s1, s2)!=0)
   	    	System.out.println("String are anagram");
   	    else 
   	    	System.out.println("String are anagram");
    }
}
