package com.wipro.video.bean;

public class PublisherBean {
	int		publisherCode;
	String	publisherName;
	String	address;
	public int getPublisherCode() {
		return publisherCode;
	}
	public void setPublisherCode(int publisherCode) {
		this.publisherCode = publisherCode;
	}
	public String getPublisherName() {
		return publisherName;
	}
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
